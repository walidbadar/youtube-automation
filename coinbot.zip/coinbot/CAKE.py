#coding=utf-8
from bs4 import BeautifulSoup
from discord.ext import commands, tasks
import discord, cloudscraper, re, requests, time

URL = 'https://coinmarketcap.com/currencies/pancakeswap/'

# Discord bot instance
bot = commands.Bot(command_prefix='~')

# Things to run when the bot connects to Discord
@bot.event
async def on_ready():
    print('Connected!')
    try:
        coin.start()

    except:
        coin.restart()
        print("Restart Loop")

@tasks.loop(minutes=1)
async def coin():
    guild = bot.get_guild(832591313283055667)  # server id
    member = guild.get_member(840276178966806539)  # bot id

    try:
        htmlscrape = cloudscraper.create_scraper()  # returns a CloudScraper instance
        coinhtmlscrape = str(htmlscrape.get(URL).content)
        coin = re.findall("priceValue \"\>\<span\>(.*?)\<\/span\>\<\/div\>", coinhtmlscrape, re.M)  # dollar price
        coinindex = re.findall("\<span class=\"icon-Caret\-(.*?)\<\!", coinhtmlscrape, re.M) #dollar index
        coinindex = str(coinindex[0])

        if coinindex[0:2] == 'up':
            await member.edit(nick="CAKE " + coin[0] + ' (↗)')
            await bot.change_presence(activity=discord.Game(name='$ 24h: '+coinindex[11:15]+'%'))

        elif coinindex[0:4] == 'down':
            await member.edit(nick="CAKE " + coin[0] + ' (↘)')
            await bot.change_presence(activity=discord.Game(name='$ 24h: -'+coinindex[13:17]+'%'))

    except:
        print("Try Again")
        time.sleep(60)

@coin.before_loop
async def before_coin():
    print('waiting...')
    await bot.wait_until_ready()

bot.run('ODQwMjc2MTc4OTY2ODA2NTM5.YJV2LA.39exFr2s-QcMx5uiihgilqpjZc4') #ME