#coding=utf-8
from bs4 import BeautifulSoup
from discord.ext import commands, tasks
import discord, cloudscraper, re, requests, time

URL = 'https://etherscan.io/gastracker'

# Discord bot instance
bot = commands.Bot(command_prefix='~')

# Things to run when the bot connects to Discord
@bot.event
async def on_ready():
    print('Connected!')
    try:
        coin.start()

    except:
        coin.restart()
        print("Restart Loop")

@tasks.loop(minutes=1)
async def coin():
    guild = bot.get_guild(832591313283055667)  # 832591313283055667 server id
    member = guild.get_member(840320394941431838)  # bot id

    try:
        htmlscrape = cloudscraper.create_scraper()  # returns a CloudScraper instance
        ethgashtmlscrape = str(htmlscrape.get(URL).content)
        #print(ethgashtmlscrape)
        ethgaslow = re.findall("Low\: (.*?) gwei", ethgashtmlscrape, re.M)  # ETH GAS Low
        #print("ETH GAS LOW: " + ethgaslow[0])
        ethgasavg = re.findall("Avg\: (.*?) gwei", ethgashtmlscrape, re.M)  # ETH GAS Avg
        #print("ETH GAS AVG: " + ethgasavg[0])
        ethgashigh = re.findall("High\: (.*?) gwei", ethgashtmlscrape, re.M)  # ETH GAS High
        #print("ETH GAS HIGH: " + ethgashigh[0])
        await member.edit(nick="⚡ " + ethgashigh[0] + ' gwei')
        await bot.change_presence(activity=discord.Game(name='Low: '+ethgaslow[0] + ', Avg: '+ethgasavg[0]))

    except:
        print("Try Again")
        time.sleep(60)

@coin.before_loop
async def before_coin():
    print('waiting...')
    await bot.wait_until_ready()

bot.run('ODQwMzIwMzk0OTQxNDMxODM4.YJWfWg.Puv68F_y3oU0-wjo4eRK8wima7g') #ME