#coding=utf-8
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions
from discord.ext import commands, tasks
import discord, cloudscraper, re, time, requests, json, datetime

# Selenium  instance
URL = 'https://coinmarketcap.com/currencies/bitcoin/'

# Discord bot instance
bot = commands.Bot(command_prefix='~')

# Things to run when the bot connects to Discord
@bot.event
async def on_ready():
    print('Connected!')
    try:
        coin.start()

    except:
        coin.restart()
        print("Restart Loop")

@tasks.loop(seconds=1)
async def coin():
    driver = ''

    guild = bot.get_guild(832591313283055667)  # server id
    member = guild.get_member(840187785063301120)  # bot id

    try:
        options = webdriver.ChromeOptions()
        options.headless = True
        driver = webdriver.Chrome(options=options)
        driver.get(URL)
        #WebDriverWait(driver, 1).until(expected_conditions.url_to_be(URL))
        time.sleep(8)
        coinhtmlscrape = driver.page_source

        coin = re.findall("priceValue \"\>\<span\>(.*?)\<\/span\>\<\/div\>", coinhtmlscrape, re.M)  # dollar price
        coin = str(coin[0])
        coin = coin.partition('.')

        coinindex = re.findall("icon-Caret\-(.*?)\<\!", coinhtmlscrape, re.M)  # dollar index
        coinindex = str(coinindex[0])
        coinindexdir = re.findall("icon-Caret\-(.*?)\"\>", coinhtmlscrape, re.M)  # dollar index direction

        if coinindexdir[0] == 'up':
            await member.edit(nick=".BTC " + coin[0] + ' (↗)')
            await bot.change_presence(activity=discord.Game(name='$ 24h: ' + coinindex[11:15] + '%'))

        elif coinindexdir[0] == 'down':
            await member.edit(nick=".BTC " + coin[0] + ' (↘)')
            await bot.change_presence(activity=discord.Game(name='$ 24h: -' + coinindex[13:17] + '%'))

        driver.quit()

    except:
        if(driver!=''):
            print("Close Chrome")
            driver.quit()
        print("Try Again")
        time.sleep(10)

@coin.before_loop
async def before_coin():
    print('waiting...')
    await bot.wait_until_ready()

bot.run('ODQwMTg3Nzg1MDYzMzAxMTIw.YJUj2Q.seZiOUoypx31HDX7Gik-A_WvElc') #BTC